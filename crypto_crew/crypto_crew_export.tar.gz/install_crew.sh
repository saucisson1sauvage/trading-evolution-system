#!/bin/bash
echo "Installing/Updating Crypto Crew on this machine..."

# Recreate folders
mkdir -p ~/freqtrade/user_data/strategies
mkdir -p ~/freqtrade/user_data/backtest_results
mkdir -p ~/freqtrade/user_data/hyperopt_results

# Move core files to home
mkdir -p ~/crypto_crew
cp autonomous_agent.py monitor_mem.sh *.sh ~/crypto_crew/
chmod +x ~/crypto_crew/*.sh

# Move strategy and config
cp config.json ~/freqtrade/user_data/
cp strategies/* ~/freqtrade/user_data/strategies/
[ -d logs ] && cp logs/* ~/crypto_crew/

echo "Installation complete. Aliases remain in your bashrc/fish if previously installed."
