import os
import subprocess
import json
import time
import random
import threading
import math
import re
import shutil
from datetime import datetime, timedelta

# Import our new Local AI Crew
from crew_agents import Crew

# --- SETTINGS ---
PROJECT_DIR = "/home/saus/crypto_crew"
STRATEGY_NAME = "EvolutionaryVolScaler"
STRAT_PATH = "/home/saus/freqtrade/user_data/strategies/EvolutionaryVolScaler.py"
CONFIG = "/home/saus/freqtrade/user_data/config.json"
USER_DIR = "/home/saus/freqtrade/user_data"
PYTHON = "/home/saus/freqtrade/.venv/bin/python"
MAIN = "/home/saus/freqtrade/freqtrade/main.py"
HISTORY_JSON = f"{PROJECT_DIR}/gen_history.json"
LIVE_THINKING = f"{PROJECT_DIR}/ai_thinking.live"
REFLECTION_LOG = f"{PROJECT_DIR}/ai_reflection.log"
IDEAS_FILE = f"{PROJECT_DIR}/creative_ideas.json"
POOL_FILE = f"{PROJECT_DIR}/pool/mating_pool.json"
BACKUP_DIR = f"{PROJECT_DIR}/backups"

class AutonomousAgent:
    def __init__(self, cores, ram_gb):
        self.cores = cores
        self.generation = 1
        self.history = []
        self.mating_pool = [] 
        self.candidate_queue = [] 
        self.best_robustness_score = -float('inf')
        self.lock = threading.Lock()
        
        # LOG THREAD LIMITS
        self.thread_limit = os.environ.get('OMP_NUM_THREADS', str(self.cores))
        self.log(f"INIT: Global Thread Limit set to {self.thread_limit}", "SYSTEM")
        
        self.load_history()
        self.load_pool()
        
        self.crew = Crew()
        
        self.brain_active = True
        self.main_task_active = False # Flag for CPU-heavy tasks (Backtesting/Hyperopt)
        
        # BRAIN WORKER: Always running LLM (GPU)
        self.brain_thread = threading.Thread(target=self.brain_worker, daemon=True)
        self.brain_thread.start()

        dash_log = open(f"{PROJECT_DIR}/dashboard.log", "a")
        cpu_list = ",".join(map(str, range(self.cores)))
        subprocess.Popen(["taskset", "-c", cpu_list, PYTHON, f"{PROJECT_DIR}/dashboard.py"], 
                         stdout=dash_log, stderr=subprocess.STDOUT, env=os.environ.copy())

    def log(self, msg, type="THINK"):
        with open(LIVE_THINKING, "a") as f:
            f.write(f"[{datetime.now().strftime('%H:%M:%S')}] [{type}] {msg}\n\n")
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

    def backup_file(self, path):
        if not os.path.exists(path): return
        name = os.path.basename(path)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = f"{BACKUP_DIR}/{name}.{ts}.bak"
        if not os.path.exists(BACKUP_DIR):
            os.makedirs(BACKUP_DIR)
        shutil.copy2(path, dest)
        backups = sorted([f for f in os.listdir(BACKUP_DIR) if f.startswith(name)], reverse=True)
        for old in backups[10:]:
            try: os.remove(f"{BACKUP_DIR}/{old}")
            except: pass

    def load_history(self):
        if os.path.exists(HISTORY_JSON):
            try:
                with open(HISTORY_JSON, 'r') as f:
                    self.history = json.load(f)
                    if self.history: 
                        self.generation = self.history[-1]['gen'] + 1
                        for entry in self.history:
                            m = entry.get('metrics', {})
                            score = self.calculate_robustness_score(m.get('profit_pct', 0), m.get('trades', 0))
                            if score > self.best_robustness_score:
                                self.best_robustness_score = score
            except: pass

    def load_pool(self):
        if os.path.exists(POOL_FILE):
            try:
                with open(POOL_FILE, 'r') as f: self.mating_pool = json.load(f)
            except: self.mating_pool = []

    def save_history(self, gen_data):
        self.history.append(gen_data)
        with open(HISTORY_JSON, 'w') as f: json.dump(self.history, f, indent=2)

    def calculate_robustness_score(self, profit_pct, trades):
        if trades <= 5: return -100
        return profit_pct * math.log10(trades + 1)

    def parse_full_metrics(self, output):
        # Remove ANSI color codes
        clean = re.sub(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])', '', output)
        metrics = {"profit_pct": 0.0, "trades": 0, "win_rate": 0.0, "drawdown": 0.0, "sharpe": 0.0}
        
        # LOG RAW OUTPUT FOR DEBUGGING (last 500 chars)
        self.log(f"PARSING RAW (tail): {clean[-500:]}", "DEBUG")

        # Structure: │ Name │ Trades │ Avg Profit% │ Tot Profit USDT │ Tot Profit% │ ...
        # Example:   │ EvolutionaryVolScaler │ 46 │ 0.71 │ 32.538 │ 3.25 │ ...
        row_match = re.search(r'│\s+' + STRATEGY_NAME + r'\s+│\s+(\d+)\s+│\s*([\d\.-]+)\s*│\s*([\d\.-]+)\s*│\s*([\d\.-]+)\s*│', clean)
        if row_match:
            metrics["trades"] = int(row_match.group(1))
            metrics["profit_pct"] = float(row_match.group(4)) # Index 4 is Tot Profit %
            
            # Win % is usually the last number in the group before drawdown
            win_match = re.search(r'(\d+\.\d+)\s+│\s+[\d\.]+ USDT', clean)
            if win_match:
                metrics["win_rate"] = float(win_match.group(1))
            
            self.log(f"Parsed Row: Trades={metrics['trades']}, Profit={metrics['profit_pct']}%, WinRate={metrics['win_rate']}%", "GA")
        else:
            self.log("ERROR: Final row regex failed.", "ERROR")
            # Last ditch: search for all percentages and take the second to last one
            pcts = re.findall(r'([\d\.-]+)%', clean)
            if len(pcts) >= 2:
                metrics["profit_pct"] = float(pcts[-2])
                metrics["win_rate"] = float(pcts[-1])
            # Fallback for different table formats
            alt_match = re.search(r'Cumulative Profit\s*│\s*([\d\.-]+)%', clean)
            if alt_match: metrics["profit_pct"] = float(alt_match.group(1))
            
            t_match = re.search(r'Total Trades\s*│\s*(\d+)', clean)
            if t_match: metrics["trades"] = int(t_match.group(1))

        # Win Rate
        wr_match = re.search(r'Win\s*%\s*│\s*([\d\.]+)', clean)
        if wr_match: metrics["win_rate"] = float(wr_match.group(1))

        # Drawdown
        dd_match = re.search(r'Absolute\s*drawdown\s*│\s*[\d\.]+\s*USDT\s*\(([\d\.]+)%\)', clean)
        if dd_match: metrics["drawdown"] = float(dd_match.group(1))

        self.log(f"Final Metrics: {json.dumps(metrics)}", "GA")
        return metrics

    def self_heal(self, error_msg, broken_code):
        self.log(f"Self-Healing triggered by: {error_msg[:100]}...", "FIX")
        fixed_code = self.crew.emergency_fixer(error_msg, broken_code)
        with open("/tmp/heal_test.py", "w") as f: f.write(fixed_code)
        syntax = subprocess.run([PYTHON, "-m", "py_compile", "/tmp/heal_test.py"], capture_output=True, env=os.environ.copy())
        if syntax.returncode == 0:
            self.log("Self-Heal successful. Source restored.", "FIX")
            return fixed_code
        else:
            self.log("Self-Heal hallucinated. Reverting to last backup.", "ERROR")
            return None

    def brain_worker(self):
        """
        Background Brain: Always utilizes GPU to generate ideas and logic snippets.
        It runs concurrently with Hyperopt.
        """
        self.log("Background Brain online.", "BRAIN")
        while self.brain_active:
            try:
                # 1. LOGIC GENERATION PHASE (Concurrent with Hyperopt, uses GPU)
                if len(self.candidate_queue) < 10: # Larger queue to keep AI busy
                    idea = "Evolutionary trend-volatility pivot"
                    if os.path.exists(IDEAS_FILE):
                        with open(IDEAS_FILE, 'r') as f: 
                            ideas = json.load(f)
                            if ideas: idea = random.choice(ideas)['hypothesis']
                    
                    with open(STRAT_PATH, 'r') as f: base_code = f.read()
                    
                    # Call LLM (GPU Intensive) - This is fine to run during Hyperopt
                    raw_snippet = self.crew.coder(base_code, idea)
                    snippet = raw_snippet.replace("```python", "").replace("```", "").strip()
                    
                    cand_code = re.sub(r'# --- \[CUSTOM_EVOLVED_LOGIC_START\] ---.*?# --- \[CUSTOM_EVOLVED_LOGIC_END\] ---', 
                                    f'# --- [CUSTOM_EVOLVED_LOGIC_START] ---\n        if self.long_logic.value == "custom_evolved":\n            {snippet}\n        # --- [CUSTOM_EVOLVED_LOGIC_END] ---', 
                                    base_code, flags=re.DOTALL)
                    
                    # 2. TESTING PHASE (Wait for CPU to be free for backtesting)
                    # We don't want to spike over 6 logical threads during Hyperopt
                    while self.main_task_active:
                        time.sleep(5) # Faster check
                    
                    tmp_strat = f"/tmp/wild_{random.randint(1000,9999)}.py"
                    with open(tmp_strat, "w") as f: f.write(cand_code)
                    
                    cpu_list = ",".join(map(str, range(self.cores)))
                    smoke_cmd = ["taskset", "-c", cpu_list, PYTHON, MAIN, "backtesting", "--strategy-path", "/tmp", "--strategy", "EvolutionaryVolScaler", 
                                "--config", CONFIG, "--timerange", "20260303-20260303", "--userdir", USER_DIR]
                    res = subprocess.run(smoke_cmd, capture_output=True, text=True, env=os.environ.copy())
                    
                    if res.returncode == 0:
                        m = self.parse_full_metrics(res.stdout)
                        raw_score = self.calculate_robustness_score(m['profit_pct'], m['trades'])
                        potential_score = raw_score * 1.5 if raw_score > 0 else raw_score # Weight wild ideas more
                        
                        with self.lock:
                            self.candidate_queue.append({
                                "code": cand_code, "score": potential_score, "metrics": m, "type": "Outsider", "idea": idea
                            })
                        self.log(f"Queued Outsider (Score: {potential_score:.2f})", "BRAIN")
                
                time.sleep(10) # Reduced sleep to keep it moving
            except Exception as e:
                self.log(f"Brain Worker Error: {e}", "ERROR")
                time.sleep(30)

    def run_hybrid_tournament(self, current_metrics):
        self.log(f"GEN {self.generation} TOURNAMENT", "GA")
        with open(STRAT_PATH, 'r') as f: current_leader_code = f.read()
        self.backup_file(STRAT_PATH)
        
        # Parallel analysis and idea generation
        bottleneck = self.crew.data_analyst(json.dumps(current_metrics))
        self.log("Generating refinement...", "GA")
        refine_idea = self.crew.creative(f"REFINE: {bottleneck}", "Aggressive")
        raw_snippet = self.crew.coder(current_leader_code, refine_idea)
        snippet = raw_snippet.replace("```python", "").replace("```", "").strip()
        refine_code = re.sub(r'# --- \[CUSTOM_EVOLVED_LOGIC_START\] ---.*?# --- \[CUSTOM_EVOLVED_LOGIC_END\] ---', 
                        f'# --- [CUSTOM_EVOLVED_LOGIC_START] ---\n        if self.long_logic.value == "custom_evolved":\n            {snippet}\n        # --- [CUSTOM_EVOLVED_LOGIC_END] ---', 
                        current_leader_code, flags=re.DOTALL)
        
        with open(STRAT_PATH, 'w') as f: f.write(refine_code)
        
        cpu_list = ",".join(map(str, range(self.cores)))
        res = subprocess.run(["taskset", "-c", cpu_list, PYTHON, MAIN, "backtesting", "--strategy", STRATEGY_NAME, "--config", CONFIG, "--timerange", "20260201-20260303", "--userdir", USER_DIR], capture_output=True, text=True, env=os.environ.copy())
        m_refine = self.parse_full_metrics(res.stdout)
        score_refine = self.calculate_robustness_score(m_refine['profit_pct'], m_refine['trades'])
        
        all_results = [{"code": refine_code, "score": score_refine, "metrics": m_refine, "type": "Refine", "idea": refine_idea}]
        
        with self.lock:
            while self.candidate_queue:
                all_results.append(self.candidate_queue.pop(0))
            
        all_results.sort(key=lambda x: x['score'], reverse=True)
        winner = all_results[0]
        
        with open(STRAT_PATH, 'w') as f: f.write(winner['code'])
        with open(POOL_FILE, 'w') as f: json.dump(all_results[:5], f, indent=2) # Keep top 5
        
        self.log(f"Tournament Finished. Winner: {winner['type']} ({winner['score']:.2f})", "GA")
        summary = f"### Tournament Gen {self.generation}\n**Winner**: {winner['type']}\n**Strategy**: {winner['idea']}"
        self.reflect(winner['metrics'], summary)
        return summary, winner['metrics']

    def reflect(self, metrics, summary):
        score = self.calculate_robustness_score(metrics['profit_pct'], metrics['trades'])
        reflection = (f"\n{'='*75}\nGEN {self.generation} REFLECTION\n{'-'*75}\n"
                     f"📈 PROFIT: {metrics['profit_pct']:.2f}% | SCORE: {score:.2f}\n"
                     f"{summary}\n")
        with open(REFLECTION_LOG, "a") as f: f.write(reflection + "\n")

    def start_loop(self):
        while True:
            try:
                self.main_task_active = False
                self.backup_file(CONFIG)

                syntax = subprocess.run([PYTHON, "-m", "py_compile", STRAT_PATH], capture_output=True, text=True, env=os.environ.copy())
                if syntax.returncode != 0:
                    with open(STRAT_PATH, 'r') as f: broken = f.read()
                    fixed = self.self_heal(syntax.stderr, broken)
                    if fixed: 
                        with open(STRAT_PATH, 'w') as f: f.write(fixed)
                    else:
                        backups = sorted([f for f in os.listdir(BACKUP_DIR) if f.startswith(os.path.basename(STRAT_PATH))], reverse=True)
                        if backups: shutil.copy2(f"{BACKUP_DIR}/{backups[0]}", STRAT_PATH)

                self.main_task_active = True 
                self.log(f"Gen {self.generation}: Training + Brainstorming...")
                
                cpu_list = ",".join(map(str, range(self.cores)))
                # REDUCED EPOCHS to 30 for speed
                # FT-Workers (2) + FT-Master (1) + Agent (1) + Dash (1) + Brain LLM (1) = 6.
                jobs = max(1, self.cores - 4)

                cmd = ["taskset", "-c", cpu_list, PYTHON, MAIN, "hyperopt",
                       "--strategy", STRATEGY_NAME, "--config", CONFIG, "--timerange", "20260101-20260303",
                       "--epochs", "30", "--hyperopt-loss", "OnlyProfitHyperOptLoss", "-j", str(jobs), 
                       "--userdir", USER_DIR, "--spaces", "buy", "sell"]
                
                # While this runs, brain_worker is hitting the GPU to make candidates
                res_opt = subprocess.run(cmd, capture_output=True, text=True, env=os.environ.copy())
                
                if res_opt.returncode != 0:
                    log_tail = res_opt.stderr[-2000:]
                    advice = self.crew.system_doctor(log_tail)
                    if "REVERT_CONFIG" in advice:
                        backups = sorted([f for f in os.listdir(BACKUP_DIR) if f.startswith(os.path.basename(CONFIG))], reverse=True)
                        if backups: 
                            shutil.copy2(f"{BACKUP_DIR}/{backups[0]}", CONFIG)
                            self.main_task_active = False
                            continue
                
                # Lifted training, keep main_task_active True for backtesting
                bt_cmd = ["taskset", "-c", cpu_list, PYTHON, MAIN, "backtesting", "--strategy", STRATEGY_NAME, "--config", CONFIG, 
                          "--timerange", "20260201-20260303", "--userdir", USER_DIR]
                res = subprocess.run(bt_cmd, capture_output=True, text=True, env=os.environ.copy())
                
                if res.returncode != 0:
                     self.main_task_active = False
                     time.sleep(10)
                     continue

                metrics_baseline = self.parse_full_metrics(res.stdout)
                thinking_summary, metrics_winner = self.run_hybrid_tournament(metrics_baseline)

                self.save_history({
                    "gen": self.generation, "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M'),
                    "metrics": metrics_winner, 
                    "dna": "Self-Healing-GA", "thinking": thinking_summary
                })
                
                self.generation += 1
                self.main_task_active = False
                subprocess.run(f"bash {PROJECT_DIR}/export_setup.sh", shell=True, env=os.environ.copy())
                time.sleep(2) # Faster cycles
            except Exception as e:
                self.main_task_active = False
                self.log(f"LOOP ERROR: {e}", "ERROR")
                time.sleep(60)

if __name__ == "__main__":
    import sys
    agent = AutonomousAgent(int(sys.argv[1]), int(sys.argv[2]))
    agent.start_loop()
